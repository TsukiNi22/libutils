/**************************************************************\
Edition:
##  @date 14/08/2026 by @author Tsukini

File Name:
##  @file Attribute-c++14.hpp

File Description:
##  Different attribute used for optimisation & other thing
##  Version for c++14 and above
\**************************************************************/

#ifndef ATTRIBUTE_CPP14_H
    #define ATTRIBUTE_CPP14_H

    //----------------------------------------------------------------//
    /* DEFINE */

    /* attributes */
    #define _nodiscard      __attribute__((warn_unused_result))     // Warn for unused return
    #define _noinline       __attribute__((noinline))               // Cancel any auto inline from the compiler
    #define _unused         __attribute__((unused))                 // Signal an unused variable
    #define _hidden         __attribute__((visibility("hidden")))   // Change the visibility on a shared lib
    #define _ctor           __attribute__((constructor))            // Execute before the main
    #define _dtor           __attribute__((destructor))             // Execute after the main
    #define _fallthrough    __attribute__((fallthrough))            // Ingore warn for no break in switch
    #ifndef NO_DEPRECATED_WARNING
        #define _deprecated(info)   [[deprecated(info)]]            // Signal a deprecated function
    #else
        #define _deprecated(info)                                   // Not defined with this flag
    #endif

    /* branch prediction */
    #define _likely         // Not defined in this version
    #define _unlikely       // Not defined in this version
    #define _likely_c(c)    __builtin_expect(!!(c), 1)  // Signal a condition that has a bigger probability of appening
    #define _unlikely_c(c)  __builtin_expect(!!(c), 0)  // Signal a condition that has a smallest probability of appening
    #define _expect(c, v)   __builtin_expect(c, v)      // Signal a condition that has a high probability of having the given value
    
    /* optimisation */
    #define _assume(expr)   __builtin_assume(expr)  // Assume a given expr as true
    #define _cold           __attribute__((cold))   // Signal a function that has a small number of use
    #define _hot            __attribute__((hot))    // Signal a function that has a huge number of use

    /* binary layout */
    #define _noaddress  // Not defined in this version
    #define _packed     __attribute__((packed)) // Remove the memory padding in a struct
    #define _alignas(n) alignas(n)              // Set the memory padding in a struct

    /* allocation hints */
    #define _alloc_size(i_size)             __attribute__((alloc_size(i_size)))                 // Signal a malloc of the given size in the argument
    #define _alloc_size_mul(i_mul, i_size)  __attribute__((alloc_size(i_mul, i_size)))          // Signal a malloc of the given size in the argument multiply by another argument
    #define _write_only(i_ptr, i_size)      __attribute__((access(write_only, i_ptr, i_size)))  // Set the mode of a ptr in the argument so that it can only be writed in the limit of the size
    #define _read_only(i_ptr, i_size)       __attribute__((access(read_only, i_ptr, i_size)))   // Set the mode of a ptr in the argument so that it can only be readed in the limit of the size
    #define _nonnull(i_ptr)                 __attribute__((nonnull(i_ptr)))                     // Warn on given null value on the given argument

#endif /* ATTRIBUTE_CPP14_H */
