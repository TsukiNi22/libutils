
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was utilsConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Dependencies
include(CMakeFindDependencyMacro)
find_dependency(OpenSSL REQUIRED)

# Custom error message if the require file doesn't exist
set(_utils_libdir "${CMAKE_CURRENT_LIST_DIR}/../../")
if(CMAKE_BUILD_TYPE STREQUAL "Asan")
    if(NOT EXISTS "${_utils_libdir}/libutils_asan.a")
        message(FATAL_ERROR
            "The Asan version of libutils is not installed.\n"
            "Please install the package 'libutils-as'."
        )
    endif()

elseif(CMAKE_BUILD_TYPE STREQUAL "Debug")
    if(NOT EXISTS "${_utils_libdir}/libutils_debug.a")
        message(FATAL_ERROR
            "The Debug version of libutils is not installed.\n"
            "Please install the package 'libutils-db'."
        )
    endif()

#elseif(CMAKE_BUILD_TYPE STREQUAL "Optimized")
else() # Default selection for noconfig
    if(NOT EXISTS "${_utils_libdir}/libutils.a")
        message(FATAL_ERROR
            "The Optimized version of libutils is not installed.\n"
            "Please install the package 'libutils-op'."
        )
    endif()
endif()

# Load and check tools
include("${CMAKE_CURRENT_LIST_DIR}/utilsTargets.cmake")
check_required_components(utils)
